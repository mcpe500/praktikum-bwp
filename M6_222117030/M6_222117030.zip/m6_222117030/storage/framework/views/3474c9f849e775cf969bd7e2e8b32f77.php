<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('/saham-detail/' . $item['symbol'])); ?>" class="text-decoration-none">
            <div class="card my-2">
                <div class="card-body">
                    <div class="row">
                        <div class="col mx-5"><?php echo e($item['company']); ?></div>
                        <div class="col mx-5">
                            <?php $__currentLoopData = explode(' ', $item['description']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $len => $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($len < 5): ?>
                                    <?php echo e($desc); ?>

                                <?php endif; ?>
                                <?php if($len == 5): ?>
                                    ...
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="col mx-5">$<?php echo e($item['price_2007']); ?></div>
                        <div class="col mx-5">
                            <?php if($item['price_rise'] > 0): ?>
                                <p class="text-success">^<?php echo e($item['price_rise']); ?></p>
                            <?php endif; ?>
                            <?php if($item['price_rise'] <= 0): ?>
                                <p class="text-danger">v<?php echo e(abs($item['price_rise'])); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.list_saham_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\VSCode\BWP\Praktikum\M6_222117030\m6_222117030\resources\views/list_saham.blade.php ENDPATH**/ ?>