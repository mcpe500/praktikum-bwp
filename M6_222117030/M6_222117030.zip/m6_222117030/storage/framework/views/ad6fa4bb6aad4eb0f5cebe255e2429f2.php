<?php $__env->startSection('open-navbar'); ?>
    <ul class="nav justify-content-end">
        <li class="nav-item">
            <h5 class="">
                <a href="<?php echo e(route('dashboard')); ?>" class="nav-link active text-light"
                    aria-current="page">
                    Saham Teratas
                </a>
            </h5>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('listSaham')); ?>" class="nav-link text-light text-decoration-underline">
                <h5>List Saham</h5>
            </a>
        </li>
    </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-5 pb-5">
        <p>List Saham</p>
        <?php echo $__env->yieldContent('list-saham'); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\VSCode\BWP\Praktikum\M6_222117030\m6_222117030\resources\views/templates/list_saham_template.blade.php ENDPATH**/ ?>