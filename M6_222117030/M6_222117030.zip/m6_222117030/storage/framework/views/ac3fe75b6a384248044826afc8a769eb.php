<?php $__env->startSection('detail-saham'); ?>
    Detail Saham
    <div class="d-flex align-items-center">
        <h1 class="ml-2"><?php echo e($data['symbol']); ?></h1>
        <?php if($data['price_rise'] > 0): ?>
            <h1>(</h1>
            <h1 class="ml-2 text-success">^<?php echo e($data['price_2007']); ?></h1>
            <h1>)</h1>
        <?php else: ?>
            <h1>(</h1>
            <h1 class="ml-2 text-danger">v<?php echo e($data['price_2007']); ?></h1>
            <h1>)</h1>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('grafik'); ?>
    <?php echo $chart->container(); ?>


    <script src="<?php echo e($chart->cdn()); ?>"></script>

    <?php echo e($chart->script()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('company-details'); ?>
    <p>
        <b>Company : </b><?php echo e($data['company']); ?>

    </p>
    <p>
        <b>Description : </b><?php echo e($data['description']); ?>

    </p>
    <p>
        <b>Initial Price : </b>$<?php echo e($data['initial_price']); ?>

    </p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('action-button'); ?>
    <div class="d-flex justify-content-evenly text-light container-fluid vw-100">
        <button class="btn bg-sell text-light" style="flex-basis: 46%">
            <h1>SELL $<?php echo e($data['price_2007'] - 1); ?></h1>
        </button>
        <button class="btn bg-buy text-light" style="flex-basis: 46%">
            <h1>BUY $<?php echo e($data['price_2007']); ?></h1>
        </button>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.detail_saham_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\VSCode\BWP\Praktikum\M6_222117030\m6_222117030\resources\views/detail_saham.blade.php ENDPATH**/ ?>